//
//  CollectionViewCell.swift
//  BouncerBuddy
//
//  Created by Sha Wu on 16/3/7.
//  Copyright © 2016年 Sheryl Hong. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
}
